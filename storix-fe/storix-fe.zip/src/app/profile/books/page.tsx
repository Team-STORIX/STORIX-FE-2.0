// src/app/profile/books/page.tsx
export default function BooksPage() {
  return (
    <div className="p-4">
      <h1>관심 작품 목록</h1>
    </div>
  )
}
