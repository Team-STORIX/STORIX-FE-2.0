// src/app/profile/writers/page.tsx
export default function WritersPage() {
  return (
    <div className="p-4">
      <h1>관심 작가 목록</h1>
    </div>
  )
}
